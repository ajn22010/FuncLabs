﻿namespace Lab2



module Program =

  [<EntryPoint>]
    let main _ =
        Test.all()
        0
